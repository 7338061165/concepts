// Arthematic Operators...
var x = 10;
var y = 20;
console.log(x + y);
console.log(x - y);
console.log(x * y);
console.log(x / y);
console.log(x % y);
// Assignment Operators...
var num1 = 10;
var num2 = 20;
num1 += num2;
console.log(num1);
// Comaprision Operators...
var a = 10;
var b = 20;
console.log(a === 30);
console.log(a !== 30);
console.log(a > b);
console.log(b > a);
// Logical Operators...
console.log((30 > 20) && (50 > 10)); // 2T     = true
console.log((30 > 20) && (5 > 10)); // 1T 1F  = false
console.log((30 > 20) || (5 > 10)); // 1T 1F  = true
console.log((3 > 20) || (5 > 10)); // 2F     = false
console.log(!((3 > 20) || (5 > 10))); // It will reverse the previous one...
// ----- && ------
// TT = T
// TF, FT = F
// ----- || -------
// TF,FT = T
// FF = F
// Ternary Operators...
var P = 10;
var Q = 20;
console.log((P > Q) ? "P IS GREATER THEN Q" : "Q IS GREATER THAN P");
