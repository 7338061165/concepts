var student = {
    name: "John",
    score: 90
};
console.log(student.name);
console.log(student.score);
// For in loop...
for (var item in student) {
    console.log(item);
    console.log(student[item]);
}
// Using Array...
var courses = ["JS", "MDB", "EJS", "AJS", "NJS"];
courses.push("HTML", "CSS");
courses.push(30);
for (var i = 0; i < courses.length; i++) {
    console.log(courses[i]);
}
// Destructuring Array...
var a = courses[0], b = courses[1], c = courses[2];
console.log(a);
console.log(b);
console.log(c);
// Destructuring Objects...
var student1 = {
    firstname: "Yadhu",
    lastname: "Nandan"
};
var firstname = student1.firstname, lastname = student1.lastname;
console.log("firstname" + " " + "lastname");
