var student = {
    name:"John",
    score:90
};
console.log(student.name);                                             // [o] : John
console.log(student.score);                                            // [o] : 90


// For in loop...

for (var  item in student){
    console.log(item);                                                  // [o] : name and score
    console.log(student[item]);                                         // [o] : John and 90
}


// Using Array...

var courses:any=["JS", "MDB", "EJS", "AJS", "NJS"];
courses.push("HTML", "CSS");
courses.push(30);

for(var i=0;i<courses.length;i++){
    console.log(courses[i]);
}                                                                          // [o] : JS, MDB,...30


// Destructuring Array...
var[a,b,c] = courses;
console.log(a);                                                                  // [o] : JS
console.log(b);                                                                  // [O] : MDB
console.log(c);                                                                  // [O] : EJS


// Destructuring Objects...
var student1 = {
    firstname:"Yadhu",
    lastname:"Nandan"
};

var{ firstname, lastname} = student1;
console.log("firstname" + " " + "lastname");                                //[O] : YadhuNandan
