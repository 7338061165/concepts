
// Type Casting....

let x:number = parseInt("Enter a number");
console.log(x+3);

let y:number = parseFloat("Enter a number");
console.log(y+3);

let z:number = prompt("Enter a number");
console.log(z+3);


let courses = ["JS", "MJS", "EJS", "AJS", "NJS"];
console.log(courses.toString);



// Object Casting...

interface Employee{
    id:number;
}

let e1:Employee;
let e2 = {id:123, name:"Yadhu"};

e1=e2    // e1 dont have values it will be easily assign to e2
e2=e1    // e2 already have values cant asign to e1



