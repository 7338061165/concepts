class Animal{
    makesound(){
        console.log("Animal Sound");
    }
}

class Dog extends Animal{
    makesound(){
        console.log("Bark");
    }
}

class Cat extends Animal{
    makesound(){
        console.log("Meoooo");
    }
}

function makeAnimalSound(animal:Animal){
    animal.makesound();
}

let animal1=new Animal();
makeAnimalSound(animal1);


let animal2=new Dog();
makeAnimalSound(animal2);


let animal3=new Cat();
makeAnimalSound(animal3);