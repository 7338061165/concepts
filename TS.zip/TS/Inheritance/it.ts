class Person{
    firstName:string;
    lastName:string;

    greet(){
        console.log("Hello World!!!")
    }
}

class Programmer extends Person{
    greet(){
        console.log("How are you...")
    }
    greetlikenormalPeople(){
        super.greet()
    }
}

var aProgrammer = new Programmer();
aProgrammer.greetlikenormalPeople();



//------------------------------//----------------------------//

class Person1{
    firstName:string;
    lastName:string;

    greet(){
        console.log("Hello World!!!")
    }
}

class Programmer1 extends Person{
    greet(){
        console.log("How are you...")
    }
    greetlikenormalPeople(){
        this.greet()
    }
}

var aProgrammer1 = new Programmer1();
aProgrammer1.greetlikenormalPeople();