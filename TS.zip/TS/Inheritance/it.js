var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Person = /** @class */ (function () {
    function Person() {
    }
    Person.prototype.greet = function () {
        console.log("Hello World!!!");
    };
    return Person;
}());
var Programmer = /** @class */ (function (_super) {
    __extends(Programmer, _super);
    function Programmer() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    Programmer.prototype.greet = function () {
        console.log("How are you...");
    };
    Programmer.prototype.greetlikenormalPeople = function () {
        _super.prototype.greet.call(this);
    };
    return Programmer;
}(Person));
var aProgrammer = new Programmer();
aProgrammer.greetlikenormalPeople();
//------------------------------//----------------------------//
var Person1 = /** @class */ (function () {
    function Person1() {
    }
    Person1.prototype.greet = function () {
        console.log("Hello World!!!");
    };
    return Person1;
}());
var Programmer1 = /** @class */ (function (_super) {
    __extends(Programmer1, _super);
    function Programmer1() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    Programmer1.prototype.greet = function () {
        console.log("How are you...");
    };
    Programmer1.prototype.greetlikenormalPeople = function () {
        this.greet();
    };
    return Programmer1;
}(Person));
var aProgrammer1 = new Programmer1();
aProgrammer1.greetlikenormalPeople();
