// If else ladder...
var x = 10;
var y = 10;
var z = 30;
if (x > y && x > z) {
    console.log(" X is Bigger");
}
else if (y > x && y > z) {
    console.log(" Y is Bigger");
}
else if (z > x && z > y) {
    console.log(" Z is Bigger");
}
else {
    console.log("Allnare Equal");
}
//Switches...
var a1 = 1;
switch (a1) {
    case 1:
        console.log("case 1");
        break;
    case 2:
        console.log("case 2");
        break;
    default:
        console.log("case default");
        break;
}
// While
var i = 0;
while (i < 10) {
    console.log(i = i + 1);
}
