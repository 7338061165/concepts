// If else ladder...

var x:number = 10;
var y:number = 10;
var z:number = 30;

if (x>y && x>z)
{
    console.log(" X is Bigger");
}

else if(y>x && y>z)
{
    console.log(" Y is Bigger");
}
else if(z>x && z>y)
{
    console.log(" Z is Bigger");
}
else
{
    console.log("Allnare Equal");
}                                                               // [o] : Z is Bigger



//Switches...
var a1:number = 1;
switch(a1)
{
    
    case 1:
    console.log("case 1");
    break;

    case 2:
    console.log("case 2");
    break;

    default:
    console.log("case default");
    break;
}                                                                      // [o]  : case 1                                        



// While
var i=0;
while(i<10)
{
    console.log(i=i+1);                                          // [o] : 1,2,3,4,5,6,7,8,9
}

    