// Arrow Functions...
var hello = function () {
    return "Hello";
};
console.log(hello());
// Passing parameters....
var hello1 = function (name) {
    return "Hello" + name;
};
console.log(hello1("Chandu"));
var multiply = function (num1, num2) {
    return num1 * num2;
};
console.log(multiply(5, 3));
// Array of Arrow Functions...
var myarray = [];
for (var i = 0; i < 10; i++) {
    myarray.push(function () { return i; });
}
for (var i = 0; i < 10; i++) {
    console.log(myarray[i]());
}
