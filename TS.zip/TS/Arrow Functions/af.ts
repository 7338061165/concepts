

// Arrow Functions...

var hello = ():string=>{
    return "Hello";

}
console.log(hello());                                               // [o] : Hello



// Passing parameters....

var hello1 = (name:string):string=>{
    return "Hello"+name;

}
console.log(hello1("Chandu"));                                         // [o] : Hello Chandu

var multiply = (num1:number, num2:number):number=>{
    return num1*num2;
    
}

console.log(multiply(5,3));                                              // [o] : 15



// Array of Arrow Functions...

var myarray:Array<any> =[];
for(var i=0;i<10;i++){
    myarray.push(():number=>{return i});
}

for(var i=0;i<10;i++){
    console.log(myarray[i]());                                           // [o] : 1,2,...9
}     



