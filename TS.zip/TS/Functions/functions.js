// First Function...
function hello() {
    return "Hello";
}
console.log(hello());
// PAssing Parameters...
function hh(name) {
    return "Hello" + name;
}
console.log(hh("Yadhu"));
// Passing Multiple Parameters...
function add(num1, num2) {
    return num1 + num2;
}
console.log(add(10, 20));
// Optional Parameters...
function display(id, name, role) {
    console.log("id", id);
    console.log("name", name);
    console.log("Role", role);
}
console.log(111, "Yadhu", "Admin");
// Function as parameters...
function calculatar(fun) {
    console.log(fun(10, 20));
}
calculatar(add);
// Function Returning...
function calculator1() {
    function subtract(num3, num5) {
        return num3 - num5;
    }
    return subtract;
}
console.log(calculator1()(20, 5));
// Anonyms Function...
var h1 = function hh(name) {
    return "Hello" + name;
};
console.log(h1("Yadhu"));
function doubleMe(x) {
    if (x && typeof x === "number") {
        console.log(x * 2);
    }
    else if (x && typeof x === "string") {
        console.log(x + " " + x);
    }
}
doubleMe(3);
doubleMe("Yadhu");
// Rest Operators...
var product = function () {
    var nums = [];
    for (var _i = 0; _i < arguments.length; _i++) {
        nums[_i] = arguments[_i];
    }
    var result = 1;
    for (var i = 0; i < nums.length; i++) {
        console.log(nums[i]);
        result *= nums[i];
    }
    return result;
};
console.log(product(1, 2, 3));
