// First Function...

function hello():string{
    return "Hello";
}
console.log(hello());                                                     // [o] : Hello




// PAssing Parameters...

function hh(name:string):string{
    return "Hello"+name;
}
console.log(hh("Yadhu"));                                                // [o] : Hello Yadhu



// Passing Multiple Parameters...

function add(num1:number, num2:number):number{
    return num1+num2;
}
console.log(add(10,20));                                                 // [o] : 30




// Optional Parameters...

function display(id:number, name:string, role:string){
    console.log("id",id);
    console.log("name",name);
    console.log("Role",role);
}
console.log(111,"Yadhu", "Admin");                                     // [o] : 111, "Yadhu", "Admin"



// Function as parameters...

function calculatar(fun:any):void{
    console.log(fun(10,20));
}
calculatar(add);                                                        // [o] : 30




// Function Returning...

function calculator1():any{
    function subtract(num3:number, num5:number):number{
        return num3-num5;
    }
    return subtract;
}

console.log(calculator1()(20,5));                                      // [o] : 15




// Anonyms Function...

var h1 = function hh(name:string):string{
    return "Hello"+name;
}
console.log(h1("Yadhu"));                                             // [o] : Hello Yadhu



// Overloading...

function doubleMe(x:number);
function doubleMe(x:string);
function doubleMe(x:any){
    if(x && typeof x==="number"){
        console.log(x*2);
    }
    else if(x && typeof x==="string"){
        console.log(x + " " + x);
    }
}
doubleMe(3);
doubleMe("Yadhu");                                                // [o]: 6 and Yadhu Yadhu




// Rest Operators...

var product = function(...nums){
    var result=1;
    for(var i=0;i<nums.length;i++){
        console.log(nums[i]);
        result*=nums[i];
    }
    return result;

}
console.log(product(1,2,3,));                                      // [o]: 1,2,3,6
















