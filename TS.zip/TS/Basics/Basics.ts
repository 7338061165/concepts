
// alert, confirm and promt...
console.log("Hello");
alert("Hello");
confirm("Do you really want to do this?");
prompt("Enter your full name");


// Integer...
var n1 = 30;
console.log(n1);


// Strings...
var s1 = "Yadhu";
var s2 = `Yadhu,Vishwa`;
console.log(s1);
console.log(s2);



//Boolean...
var b1 = true;
var b2 = false;
console.log(b1);
console.log(b2);



//Any...
var a1 = {
    productid: 1,
    ptoductname: "Iphone",
    productprice: 11000
};
console.log(a1);



// Homogenous Array...
var array1 = ["Js", "MJs", "AJs"];
console.log(array1);
console.log(array1[0]);
console.log(array1.length);



// Heterogenous Array...
var array2 = ["Js", 123, true];
console.log(array2);
console.log(array2[0]);
console.log(array2.length);



// enum...

enum Gender{
    Male,
    Female
}
console.log(Gender.Male);
console.log(Gender.Female);

enum weekend{
    satarday=6,
    sunday=7
}
console.log(weekend[6]);
console.log(weekend[7]);