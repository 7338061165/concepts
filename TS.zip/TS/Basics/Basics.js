// alert, confirm and promt...
console.log("Hello");
alert("Hello");
confirm("Do you really want to do this?");
prompt("Enter your full name");


// Integer...
var n1 = 30;
console.log(n1);



// Strings...
var s1 = "Yadhu";
var s2 = "Yadhu,Vishwa";
console.log(s1);
console.log(s2);



//Boolean...
var b1 = true;
var b2 = false;
console.log(b1);
console.log(b2);



//Any...
var a1 = {
    productid: 1,
    ptoductname: "Iphone",
    productprice: 11000
};
console.log(a1);



// Homogenous Array...
var array1 = ["Js", "MJs", "AJs"];
console.log(array1);
console.log(array1[0]);
console.log(array1.length);



// Heterogenous Array...
var array2 = ["Js", 123, true];
console.log(array2);
console.log(array2[0]);
console.log(array2.length);


// enum...
var Gender;
(function (Gender) {
    Gender[Gender["Male"] = 0] = "Male";
    Gender[Gender["Female"] = 1] = "Female";
})(Gender || (Gender = {}));
console.log(Gender.Male);
console.log(Gender.Female);


var weekend;
(function (weekend) {
    weekend[weekend["satarday"] = 6] = "satarday";
    weekend[weekend["sunday"] = 7] = "sunday";
})(weekend || (weekend = {}));
console.log(weekend[6]);
console.log(weekend[7]);
