// Creating Class...

class Passenger{
    firstName:string;
    lastName:string;
    frequentFlyerNum:number;

    // Adding Constructor...

    constructor(firstName:string, lastName:string,frequentFlyerNum:number){

        this.firstName=firstName;
        this.lastName=lastName;
        this.frequentFlyerNum=frequentFlyerNum;
        
    }
}

var passenger = new Passenger("John","Bailey",123);
console.log(passenger.firstName+" "+passenger.lastName+" "+passenger.frequentFlyerNum);


var passenger1 = new Passenger("John","Bailey",123);
console.log(passenger1.firstName+" "+passenger1.lastName+" "+passenger1.frequentFlyerNum);





// Adding Function to Class....

class Passengerr{
    firstName:string;
    lastName:string;
    frequentFlyerNum:number;

    constructor(firstName:string, lastName:string,frequentFlyerNum:number){

        this.firstName=firstName;
        this.lastName=lastName;
        this.frequentFlyerNum=frequentFlyerNum;
        
    }
    display(){
        console.log(this.firstName+" "+this.lastName+" "+this.frequentFlyerNum)
    }
}



var passengerr = new Passengerr("John","Bailey",123);
passengerr.display();

var passengerr1 = new Passengerr("John","Bailey",123);
passengerr1.display();




// For Loop in Class



class Passengerrr{
    firstName:string;
    lastName:string;
    frequentFlyerNum:number;

    constructor(firstName:string, lastName:string,frequentFlyerNum:number){

        this.firstName=firstName;
        this.lastName=lastName;
        this.frequentFlyerNum=frequentFlyerNum;
        
    }
    display(){
        console.log(this.firstName+" "+this.lastName+" "+this.frequentFlyerNum)
    }
}



var passengerrr = new Passengerrr("John","Bailey",123);
passengerrr.display();

var passengerrr1 = new Passengerrr("John","Bailey",123);
passengerrr1.display();



for(let item in passengerrr){
    if(passengerrr[item] instanceof Function){
        continue;
    }
    else
    {
        console.log(item);
        console.log(passengerrr[item]);
    }
}







// Interface Class...


interface IFlight{
    flightNo:number;
    from:string;
    to:string;
    display():void;
}

class Flight implements IFlight{
    flightNo:number;
    from:string;
    to:string;
    
    constructor(flightNo:number, from:string,to:string){

        this.flightNo = flightNo;
        this.from = from;
        this.to = to;
    }
    display(){
        console.log(this.flightNo+" "+this.from+" "+this.to)
    }
}

var flight = new Flight(123,"Hiriyur","Banglore");
flight.display();








