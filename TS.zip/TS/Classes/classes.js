// Creating Class...
var Passenger = /** @class */ (function () {
    // Adding Constructor...
    function Passenger(firstName, lastName, frequentFlyerNum) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.frequentFlyerNum = frequentFlyerNum;
    }
    return Passenger;
}());
var passenger = new Passenger("John", "Bailey", 123);
console.log(passenger.firstName + " " + passenger.lastName + " " + passenger.frequentFlyerNum);
var passenger1 = new Passenger("John", "Bailey", 123);
console.log(passenger1.firstName + " " + passenger1.lastName + " " + passenger1.frequentFlyerNum);
// Adding Function to Class....
var Passengerr = /** @class */ (function () {
    function Passengerr(firstName, lastName, frequentFlyerNum) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.frequentFlyerNum = frequentFlyerNum;
    }
    Passengerr.prototype.display = function () {
        console.log(this.firstName + " " + this.lastName + " " + this.frequentFlyerNum);
    };
    return Passengerr;
}());
var passengerr = new Passengerr("John", "Bailey", 123);
passengerr.display();
var passengerr1 = new Passengerr("John", "Bailey", 123);
passengerr1.display();
// For Loop in Class
var Passengerrr = /** @class */ (function () {
    function Passengerrr(firstName, lastName, frequentFlyerNum) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.frequentFlyerNum = frequentFlyerNum;
    }
    Passengerrr.prototype.display = function () {
        console.log(this.firstName + " " + this.lastName + " " + this.frequentFlyerNum);
    };
    return Passengerrr;
}());
var passengerrr = new Passengerrr("John", "Bailey", 123);
passengerrr.display();
var passengerrr1 = new Passengerrr("John", "Bailey", 123);
passengerrr1.display();
for (var item in passengerrr) {
    if (passengerrr[item] instanceof Function) {
        continue;
    }
    else {
        console.log(item);
        console.log(passengerrr[item]);
    }
}
var Flight = /** @class */ (function () {
    function Flight(flightNo, from, to) {
        this.flightNo = flightNo;
        this.from = from;
        this.to = to;
    }
    Flight.prototype.display = function () {
        console.log(this.flightNo + " " + this.from + " " + this.to);
    };
    return Flight;
}());
var flight = new Flight(123, "Hiriyur", "Banglore");
flight.display();
