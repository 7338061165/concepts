// Public...
var Student = /** @class */ (function () {
    function Student() {
    }
    return Student;
}());
var student = new Student();
student.name = "John";
// Public Readonly....
var Student1 = /** @class */ (function () {
    function Student1() {
        this.name = "John";
    }
    return Student1;
}());
var student1 = new Student1();
// Private....
var Student2 = /** @class */ (function () {
    function Student2() {
    }
    Student2.prototype.display = function () {
        console.log(this._name);
    };
    Object.defineProperty(Student2.prototype, "name", {
        get: function () {
            return this._name;
        },
        set: function (name) {
            this._name = name;
        },
        enumerable: false,
        configurable: true
    });
    return Student2;
}());
var student2 = new Student();
student.name = "Johnn";
console.log(student.name);
