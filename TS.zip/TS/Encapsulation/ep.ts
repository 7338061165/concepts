

// Public...

class Student{
    public name:string;
}
var student = new Student();
student.name = "John";


// Public Readonly....

class Student1{
    public readonly name:string = "John";
}
var student1 = new Student1();


// Private....

class Student2{
    private _name:string;
    display(){
        console.log(this._name);
    }
    get name():string{
        return this._name;
    }
    set name(name:string){
        this._name = name;
    }
}

var student2 = new Student();
student.name="Johnn";
console.log(student.name);