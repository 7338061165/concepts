// Interface...
var product1 = {
    id: 111,
    name: "Yadhu",
    role: "Admin",
    price: 30000,
    discription: "Awesome"
};
var add;
var sub;
add = function (x, y) {
    console.log(x + y); // Functional Interface...
};
sub = function (a, b) {
    return (a - b); // Return Functional Interface...
};
