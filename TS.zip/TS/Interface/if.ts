
// Interface...

interface product{
    id:number;
    name:string;
    role:string;
    price:number;
    discription:string;
    display():void;
}


var product1:product = {
    id:111,
    name:"Yadhu",
    role:"Admin",
    price:30000,
    discription:"Awesome",
    display():void{
        console.log(this.id+" "+this.name);
    }
}





// Functional Interface and Return Functional Interface....




interface Add{
    (x:number, y:number):void
}


interface Sub{
    (x:number, y:number):number
}

var add:Add
var sub:Sub

add = function(x:number, y:number):void{
    console.log(x+y);                                   // Functional Interface...
}


sub = function(a:number, b:number):number{
    return(a-b);                                        // Return Functional Interface...
}


    

// Array Interface....
// String......

interface studentName{
    [index:number]:string;
}

var studentNames : studentName = ["John","Boh","Jos"];


for(var item in studentNames){
    console.log(item);
    console.log(studentNames[item]);
}
    
    

// Number...

interface studentscore{
    [index:string]:number;
}

var studentscores : studentscore = {};
studentscores["John"] = 91;
studentscores["Boh"] = 93;

for(var item in studentscores){
    console.log(item);
    console.log(studentscores[item]);
}





// Extending Interface...

interface Exterior{
    color:string;
    Doors:number;
}
    


interface Interior{
    seats:number;
    auto:boolean;
}
    
interface Car extends Exterior,Interior{
    make:string;
    model:string;
    year:number;
}


var myCar:Car={
    make:"Honda",
    model:"Civic",
    year:2018,
    color:"Black"
    Doors:5,
    seats:5,
    auto:true
}


    