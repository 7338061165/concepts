

// Events...

var events = require("events");
var emitter = new events();

emitter.on("invoked", function(){
    console.log("Costom event invoked");
});

emitter.emit("update events");

