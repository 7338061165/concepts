

// Before ES6.........




// Classes and Objects...


// This is the method which can be extended as class

function Trainer(){
    this.name = "Yadhunandan BM";
}



// Setting methods using Prototype...

Trainer.prototype.setName = function(name){
    this.name=name;
}


// Setting methods using Prototype...

Trainer.prototype.sayHello = function(){
    console.log(this.name);
}



var myTrainer = new Trainer();
myTrainer.setNama("Yadhu");
myTrainer.sayHello();



// After ES6....


class consultant{
    name ="";

    setName(){
        this.name="name";
    }
    
    sayHello(){
        console.log(this.name);
    }
}

myConsultant = new consultant();
myConsultant.setName = "Ram";
myConsultant.sayHello();
