



function sayHelloFromRequire(){
    console.log("Hello from required file");
}
sayHelloFromRequire();




