var athletics = require('./n7');
athletics.relay();
athletics.longjump()



