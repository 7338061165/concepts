

// Sync - Its Executes sequentually step by step from top to bottom.....

function getUserInfo(){
    setTimeout(()=>{
        console.log("User Info will be returned");
    },3000);
}

function getUserContacts(){
    console.log("Returns the contacts of the user");
}



try{
    console.log("Get User Info");
}
catch(e){
    console.log('Error is Getting...')
}
finally{
    console.log("Return User");
}


getUserContacts();



