

console.log("Hello-World");

var a=7
var b=2
var c=a+b
console.log("The output is "+c)


var http = require('http')

http.createServer(function(req,res){
    res.writeHead(200,{'content-Type':'text/html'})
    res.end("Welcome back Sudeep")
}).listen(8080)

