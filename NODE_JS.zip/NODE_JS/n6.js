

// This.Keyword...


// Using This.Keyword insde an Object....


var courseWork = {
    getCourses:function(courseName){
        console.log(this);
    }
}
courseWork.getCourses("Node JS");


// Using This.Keyword insde an Class....


class courses{
    courseName='';
    getAllCourses(){
        this.courseName = "MEAN-STACK";
        console.log(this.courseName);           // Inside class to access variable...
    }
    setCourse(){
        var c2=this.courseName;
        c2 = 'Hello' + c2;
        this.getAllCourses();                  // Inside class to access Method...
    }
}

var c = new courses();
c.getAllCourses();




