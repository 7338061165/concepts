


// Promises - Resolve.....


function getUserContacts(){
    console.log("Returns the contacts of the user");
}

var user = new Promise((resolve,reject)=>{
    console.log("Getting user info");
    resolve("Return User Info");
}).then((data)=>{
    getUserContacts();
}).catch((e)=>{
    console.log(e);
});

