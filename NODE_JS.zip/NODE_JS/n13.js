

// Pipes...

var fs = require('fs');
var readableStream = fs.createReadStream('in.text');
var writableStream = fs.createWriteStream('out.text');    
readableStream.pipe(writableStream);

// in our folder only 'in.text' file is there using pipes i created 'out.text'.....