
// Modules....


function relay(){
    console.log('This is the relay function');
}


function longjump(){
    console.log('This is the longjump function');
}

module.exports.relay=relay;

module.exports.longjump=longjump;