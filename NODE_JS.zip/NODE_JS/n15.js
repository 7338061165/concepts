

//  Async....

function getUserInfo(){
    setTimeout(()=>{
        console.log("User Info will be returned");
    },3000);
}

function getUserContacts(){
    console.log("Returns the contacts of the user");
}

getUserInfo();
getUserContacts();