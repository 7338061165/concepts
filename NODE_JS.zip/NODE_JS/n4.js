



var helloFromRequire = require('./n5.js');




// Global Objects - Objects available throught the application called as Global Objects
// Eg :- console, export, module etc.....


console.log("Hello-World");       // 1) Console
console.log(__dirname);           // 2) __dirname
console.log(__filename);          // 3) __filename


function printstuff(){
    console.log(" I came after 5 sec");
}
setTimeout(printstuff,5000);    // claa-back...







