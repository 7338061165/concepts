

// Streams-Writable...



var fs = require('fs');
var readStream = fs.createReadStream(__dirname +'/readme.txt', 'utf8');
var WriteStream = fs.createWriteStream(__dirname +'/writeme.txt');




readStream.on('data', function(chunk){
    console.log('new chunck recived');
    WriteStream.write(chunk);
})
