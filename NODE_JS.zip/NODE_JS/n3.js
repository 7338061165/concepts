

// Objects.....

var courses = {
    name:"Yadhu",
    Age:"23",
    Job : "SE"
}
console.log(courses);
console.log(courses.name);
console.log(courses.Job);


// Functions...

// Defining function.....
function getCourses(){
    console.log("Get All the Courses");
}
getCourses();// Calling function...




// Defining function.....
function getCategoryCourses(id){
    console.log("Category Id:"+id);
}
getCategoryCourses(10);// Calling function...




// Anonyms Function...


var getUsers = function(){
    console.log("This is getUsers");
}


// We can pass a function in Parameter...

function displayUsers(funcName){
    funcName();
}
displayUsers(getUsers);




// Arrow Functions...

getDepartments=(id)=>{
    console.log("Yadhu Age is :" + id);

}
getDepartments(23);






