

// Streams-readable...

var fs = require('fs');
var readstream = fs.createReadStream('index.html','utf8');

readstream.on('data', function(chunck){
    console.log('---------------------Start--------------------------');
    console.log(chunck);
})

readstream.on('end', function(chunck){
    console.log('---------------------End--------------------------');
})    