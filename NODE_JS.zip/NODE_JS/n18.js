

// Promises - Reject...




// Promises - Resolve.....


function getUserContacts(){
    console.log("Returns the contacts of the user");
}

var user = new Promise((resolve,reject)=>{
    console.log("Getting user info");
    reject("Failed to Return User");
}).then((data)=>{
    getUserContacts();
}).catch((e)=>{
    console.log(e);
});

